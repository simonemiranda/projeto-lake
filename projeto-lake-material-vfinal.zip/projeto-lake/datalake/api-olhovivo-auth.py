import requests
import os
import io
import json
from datetime import datetime
from confluent_kafka import Producer, Consumer, KafkaException
from minio import Minio
import uuid



def autenticarOlhoVivo():
    apikey = os.getenv("token_olhovivo")
    url = 'https://api.olhovivo.sptrans.com.br/v2.1/Login/Autenticar?token=' + apikey

    payload = {}
    headers = {}

    response = requests.request("POST", url, headers=headers, data=payload)
    get_cookie = response.cookies
    cookie = get_cookie.get("apiCredentials")
    print("Autenticando olhovivo")
    return cookie

def buscarLinhas(cookie):

    url = "https://api.olhovivo.sptrans.com.br/v2.1/Linha/Buscar?termosBusca=8000"

    payload = {}
    headers = {
        'Cookie': 'apiCredentials=' + cookie
    }

    response = requests.request("GET", url, headers=headers)
    print("Buscando linhas")
    return response.json()

def ingestaoKafka(data):
    print("Ingestão kafka")
    broker = 'localhost:9092'
    topic = 'api.user'
    producer = Producer({
    'bootstrap.servers' : broker,
    })
    producer.produce(topic, json.dumps(data))
    producer.flush()
    print(f"Message sent to topic '{topic}': {json.dumps(data)}")

def consumeKakfa():
    broker = 'localhost:9092'
    topic = 'api.user'
    group_id = 'api-consumer-group'

    consumer_config = {
        'bootstrap.servers': broker,
        'group.id': group_id,
        'auto.offset.reset': 'earliest', 
        'enable.auto.commit': True,  
    }

    consumer = Consumer(consumer_config)
    consumer.subscribe([topic])

    try:
        print(f"Consuming messages from topic '{topic}'...")
        while True:
            msg = consumer.poll(1.0)  # Wait for a message for 1 second
            if msg is None:
                continue
            if msg.error():
                print(f"Kafka error: {msg.error()}")
                continue

            # Process the message
            message_value = msg.value().decode('utf-8')
            print(f"Received message: {message_value}")
            saveMinio(message_value)

    except KafkaException as e:
        print(f"Kafka exception: {str(e)}")
    except Exception as e:
        print(f"Error: {str(e)}")
    finally:
        consumer.close()

def saveMinio(message_value):
    minio_client = Minio(
       "localhost:9050",  
       access_key="datalake",  
       secret_key="datalake", 
       secure=False,            
   )
    bucket_name = "raw"

    if minio_client.bucket_exists(bucket_name):
       print("bucket RAW existe")
    else:
       print("bucket RAW não existe")

    current_time = datetime.now().strftime("%Y-%m-%d")
    # Generate a new GUID
    new_guid = str(uuid.uuid4())

    object_name = f"olhovivo/buscar/{current_time}/{new_guid}.json" 
   
    data = io.BytesIO(bytes(message_value, 'utf-8'))

    minio_client.put_object(
        bucket_name,
        object_name,
        data,
        length=len(message_value),
        content_type="application/json",
        )
    print(f"Message saved to MinIO as '{object_name}'")   
    
def workflow():
    cookie = autenticarOlhoVivo()
    data = buscarLinhas(cookie)  
    ingestaoKafka(data)
    consumeKakfa()

workflow()    