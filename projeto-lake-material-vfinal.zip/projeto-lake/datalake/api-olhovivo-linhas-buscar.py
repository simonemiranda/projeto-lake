import requests
import os

cookie = os.getenv("cookie_olhovivo")
print(cookie)

url = "https://api.olhovivo.sptrans.com.br/v2.1/Linha/Buscar?termosBusca=9000"

payload = {}
headers = {
    'Cookie': 'apiCredentials=' + cookie
}

response = requests.request("GET", url, headers=headers, data=payload)

print(response.text)
