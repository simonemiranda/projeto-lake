from pyspark.sql import SparkSession
from delta.tables import *
import datetime
import pytz

spark = (
    SparkSession
    .builder
    .appName('Pipeline_Raw_To_Trusted')
    .master("spark://172.18.0.5:7077")  
    .config('spark.sql.extensions','oi.delta.DeltaSparkSessionExtension')
    .config('spark.sql.catalog.spark_catalog', 'org.apache.spark.sql.delta.catalog.DeltaCatalog')
    .getOrCreate()
)


json_data = '''
[
    {"id": 1, "name": "John Doe", "age": 30},
    {"id": 2, "name": "Jane Doe", "age": 25}
]
'''

# Create a DataFrame from the hardcoded JSON string
rdd = spark.sparkContext.parallelize([json_data])
df_raw = spark.read.json(rdd)

# date = datetime.datetime.today()
# d = date.astimezone(pytz.timezone('America/Sao_Paulo'))
# d.strftime('%Y-%m-%d')
# path_raw = 's3a://raw/olhovivo/buscar/{}/'.format(d.strftime('%Y-%m-%d'))
# path_trusted = 's3a://trusted/olhovivo/buscar/{}/'.format(d.strftime('%Y-%m-%d'))

# df_raw = spark.read.json(path_raw)