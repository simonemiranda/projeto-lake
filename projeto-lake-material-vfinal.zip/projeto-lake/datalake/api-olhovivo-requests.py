import requests

def make_request(
    method, 
    endpoint: str,
    params: dict(str,str) = None,
    headers: dict(str,str) = None,
) -> requests.Response:
    params = params or {}
    headers = headers or {}
    base_url = "https://api.olhovivo.sptrans.com.br/v2.1"
    url = f"{base_url}/{endpoint}"

    response = requests.request(method, url, headers=headers, params=params)
    return response.json()

    result = make_request(
        method="POST",
        endpoint="Login/Autenticar",
        params={
            "token": "514992f4bed4dcd5f38fd37282fbb2d12f87f30f39894abef44e4c8f2a6563a4"
        }
    )

    print(result)