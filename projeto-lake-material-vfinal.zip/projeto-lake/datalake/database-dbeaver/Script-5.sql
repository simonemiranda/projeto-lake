


select * from analytics.routes limit 5
select * from analytics.eye_linha limit 5
select * from analytics.eye_posicao_veiculos limit 5


select * from analytics.trips limit 5
select * from analytics.shapes limit 5


select * from analytics.routes where route_id = '1012-21'

select * 
from analytics.eye_linha l
inner join analytics.routes r on l.linha = r.route_id 


select * 
from analytics.eye_linha l
inner join analytics.routes r on l.linha = r.route_id
inner join analytics.trips t on l.linha = t.route_id
