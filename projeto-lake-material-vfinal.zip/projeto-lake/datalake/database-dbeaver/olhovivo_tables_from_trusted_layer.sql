

--|table::LINHAS
--====================================================
drop table if exists analytics.eye_linhas;

create external table analytics.eye_linhas
(
cl string
, lc string
, lt string
, sl string
, tl string
, tp string
, ts string
)
--row format delimited fields terminated by ','
stored as parquet
location 's3a://trusted/olho-vivo/linhas/buscar-linhas';


select * from analytics.eye_linhas limit 5;




--|table::POSICAO DE VEICULOS
--====================================================
drop table if exists raw.eye_posicao_veiculos;
create external table raw.eye_posicao_veiculos
(
vs_p string
, cl string
, c string

)
stored as parquet
location 's3a://trusted/olho-vivo/posicao-veiculos/buscar-posicao';

select * from raw.eye_posicao_veiculos limit 5;


drop table if exists analytics.eye_posicao_veiculos;
create external table analytics.eye_posicao_veiculos
(
posicaoId string
, codigoLinha string
, linha string

)

insert into analytics.eye_posicao_veiculos
select vs_p, cl, c 
from raw.eye_posicao_veiculos


select * from analytics.eye_posicao_veiculos limit 5;


