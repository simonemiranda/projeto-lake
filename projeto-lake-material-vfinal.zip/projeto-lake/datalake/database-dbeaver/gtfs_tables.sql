
create database raw;


--|table::ROUTES
--====================================================
drop table if exists raw.routes;

create external table raw.routes
(
route_id string
, agency_id string
, route_short_name string
, route_long_name string
, route_type string
, route_color string
, route_text_color string
)
row format delimited fields terminated by ','
stored as textfile
location 's3a://raw/gtfs/routes';

--load data inpath 's3a://raw/gtfs/routes.txt' INTO TABLE analytics.raw_routes;
--select * from analytics.raw_routes limit 5;

--====================================================
drop table if exists analytics.routes;

create external table analytics.routes
(
route_id string
, agency_id string
, route_short_name string
, route_long_name string
, route_type string
, route_color string
, route_text_color string
)
stored as parquet
location 's3a://trusted/gtfs/routes/';

insert into analytics.routes
select 
	replace(route_id, '"', '') as route_id
	, replace(agency_id, '"', '') as agency_id
	, replace(route_short_name, '"', '') as route_short_name
	, replace(route_long_name, '"', '') as route_long_name
	, replace(route_type, '"', '') as route_type
	, replace(route_color, '"', '') as route_color
	, replace(route_text_color, '"', '') as route_text_color
from raw.routes 
where route_id != '"route_id"' 
order by route_id;


select * from raw.routes limit 5;
select * from analytics.routes limit 5;


--|table::AGENCIES
--====================================================
--//db RAW
--------------------------
drop table if exists raw.agencies;

create external table raw.agencies
(
agency_id string
, agency_name string
, agency_url string
, agency_timezone string
, agency_lang string
)
row format delimited fields terminated by ','
stored as textfile
location 's3a://raw/gtfs/agency';

select * from raw.agencies limit 5;


--//db ANALYTICS
--------------------------
drop table if exists analytics.agencies;

create external table analytics.agencies
(
agency_id string
, agency_name string
, agency_url string
, agency_timezone string
, agency_lang string
)
row format delimited fields terminated by ','
stored as textfile
location 's3a://trusted/gtfs/agencies';

insert into analytics.agencies
select 
	replace(agency_id, '"', '') as agency_id
	, replace(agency_name, '"', '') as agency_name
	, replace(agency_url, '"', '') as agency_url
	, replace(agency_timezone, '"', '') as agency_timezone
	, replace(agency_lang, '"', '') as agency_lang
from raw.agencies 
where agency_id != '"agency_id"' 
order by 1;


select * from analytics.agencies limit 5;



--|table::STOPS
--====================================================
--//db RAW
--------------------------
drop table if exists raw.stops;

create external table raw.stops
(
stop_id string
, stop_name string
, stop_desc string
, stop_lat string
, stop_lon string
)
row format delimited fields terminated by ','
stored as textfile
location 's3a://raw/gtfs/stops';

select * from raw.stops limit 5;


--//db ANALYTICS
--------------------------
drop table if exists analytics.stops;

create external table analytics.stops
(
stop_id string
, stop_name string
, stop_desc string
, stop_lat string
, stop_lon string
)
row format delimited fields terminated by ','
stored as textfile
location 's3a://trusted/gtfs/stops';

insert into analytics.stops
select 
	replace(stop_id, '"', '') as stop_id
	, replace(stop_name, '"', '') as stop_name
	, replace(stop_desc, '"', '') as stop_desc
	, replace(stop_lat, '"', '') as stop_lat
	, replace(stop_lon, '"', '') as stop_lon
from raw.stops 
where stop_id != '"stop_id"' 
order by 1;


select * from analytics.stops limit 5;



--|table::TRIPS
--====================================================
--//db RAW
--------------------------
drop table if exists raw.trips;

create external table raw.trips
(
route_id string
, service_id string
, trip_id string
, trip_headsign string
, direction_id string
, shape_id string
)
row format delimited fields terminated by ','
stored as textfile
location 's3a://raw/gtfs/trips';

select * from raw.trips limit 5;

--//db ANALYTICS
--------------------------
drop table if exists analytics.trips;

create external table analytics.trips
(
route_id string
, service_id string
, trip_id string
, trip_headsign string
, direction_id string
, shape_id string
)
stored as parquet
location 's3a://trusted/gtfs/trips/';

insert into analytics.trips
select 
	replace(route_id, '"', '') as route_id
	, replace(service_id, '"', '') as service_id
	, replace(trip_id, '"', '') as trip_id
	, replace(trip_headsign, '"', '') as trip_headsign
	, replace(direction_id, '"', '') as direction_id
	, replace(shape_id, '"', '') as shape_id
from raw.trips 
where trip_id != '"trip_id"' 
order by trip_id;

select * from analytics.trips limit 5;




--|table::SHAPES
--====================================================
--//db RAW
--------------------------
drop table if exists raw.shapes;

create external table raw.shapes
(
shape_id string
, shape_pt_lat string
, shape_pt_lon string
, shape_pt_sequence string
, shape_dist_traveled string
)
row format delimited fields terminated by ','
stored as textfile
location 's3a://raw/gtfs/shapes';

select * from raw.shapes limit 5;

--//db ANALYTICS
--------------------------
drop table if exists analytics.shapes;

create external table analytics.shapes
(
shape_id string
, shape_pt_lat string
, shape_pt_lon string
, shape_pt_sequence string
, shape_dist_traveled string
)
stored as parquet
location 's3a://trusted/gtfs/shapes/';

insert into analytics.shapes
select 
	replace(shape_id, '"', '') as shape_id
	, replace(shape_pt_lat, '"', '') as shape_pt_lat
	, replace(shape_pt_lon, '"', '') as shape_pt_lon
	, replace(shape_pt_sequence, '"', '') as shape_pt_sequence
	, replace(shape_dist_traveled, '"', '') as shape_dist_traveled
from raw.shapes 
where shape_id != '"shape_id"' 
order by shape_id, shape_pt_sequence;

select count(1) from analytics.shapes
select * from analytics.shapes limit 5



--|table::FREQUENCIES
--====================================================
--//db RAW
--------------------------
drop table if exists raw.frequencies;

create external table raw.frequencies
(
trip_id string
, start_time string
, end_time string
, headway_secs string
)
row format delimited fields terminated by ','
stored as textfile
location 's3a://raw/gtfs/frequencies';

select * from raw.frequencies limit 5;

--//db ANALYTICS
--------------------------
drop table if exists analytics.frequencies;

create external table analytics.frequencies
(
trip_id string
, start_time string
, end_time string
, headway_secs string
)
stored as parquet
location 's3a://trusted/gtfs/frequencies/';

insert into analytics.frequencies
select 
	replace(trip_id, '"', '') as trip_id
	, replace(start_time, '"', '') as start_time
	, replace(end_time, '"', '') as end_time
	, replace(headway_secs, '"', '') as headway_secs
from raw.frequencies 
where trip_id != '"trip_id"' 
order by 1;

select * from analytics.frequencies limit 5;




