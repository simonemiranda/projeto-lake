
INFORMAÇÕES SOBRE A API OLHO VIVO
1. Acesso
	http://api.olhovivo.sptrans.com.br/v2.1

2. Autenticação e credenciais
	ENDPOINTs
	GET /Login/Autenticar?token={token}
	Exemplo: https://api.olhovivo.sptrans.com.br/v2.1/Login/Autenticar?token=1V5D54V5CXZV25Z4XD5FG4VZ1V35D
	
3. Linhas
Realiza uma busca das linhas do sistema com base no parâmetro informado

	ENDPOINTS
	3.1 Buscar
	Realiza uma busca das linhas do sistema com base no parâmetro informado. Se a linha não é encontrada então é realizada uma busca fonetizada na denominação das linhas.
		GET /Linha/Buscar?termosBusca={codigoLinha}
		Exemplo: https://api.olhovivo.sptrans.com.br/v2.1/Linha/Buscar?termosBusca=8070
	
	3.2 BuscarLinhaSentido
	Realiza uma busca das linhas do sistema com base no parâmetro informado. Se a linha não é encontrada então é realizada uma busca fonetizada na denominação das linhas. 
	A linha retornada será unicamente aquela cujo sentido de operação seja o informado no parâmetro sentido.
		GET /Linha/BuscarLinhaSentido?termosBusca={codigoLinha}&sentido={sentido}
		Exemplo: http://api.olhovivo.sptrans.com.br/v2.1/Linha/Buscar?termosBusca=8010&sentido=Lapa

4. Paradas
	ENDPOINTS
	4.1 Buscar
	Realiza uma busca fonética das paradas de ônibus do sistema com base no parâmetro informado. A consulta é realizada no nome da parada e também no seu endereço de localização.
		GET /Parada/Buscar?termosBusca={termosBusca}
		Exemplo: https://api.olhovivo.sptrans.com.br/v2.1/Parada/Buscar?termosBusca=Afonso
	
	
	4.2 BuscarParadasPorLinha
		GET /Parada/BuscarParadasPorLinha?codigoLinha={codigoLinha}
		Exemplo: 
	
	4.3 BuscarParadasPorCorredor
		GET /Parada/BuscarParadasPorCorredor?codigoCorredor={codigoCorredor}
		Exemplo: 
	

5. Corredores
	Retorna uma lista com todos os corredores
	GET /Corredor
	Exemplo: https://api.olhovivo.sptrans.com.br/v2.1/Corredor
	
	
6. Empresas
	Retorna uma lista com todos as empresa
	GET /Empresa
	Exemplo: https://api.olhovivo.sptrans.com.br/v2.1/Empresa
	
	
7. Posição dos veículos
	Retorna uma lista completa com a última localização de todos os veículos mapeados com suas devidas posições
	7.1 Get
	Retorna uma lista completa com a última localização de todos os veículos mapeados com suas devidas posições lat / long
		GET /Posicao
		Exemplo: https://api.olhovivo.sptrans.com.br/v2.1/Posicao
		
	7.2 Linha
	Retorna uma lista com todos os veículos de uma determinada linha com suas devidas posições lat / long
		GET /Posicao/Linha?codigoLinha={codigoLinha}
		Exemplo: https://api.olhovivo.sptrans.com.br/v2.1/Posicao/Linha?codigoLinha=8020
	
	7.3 Garagem
	Retorna uma lista completa todos os veículos mapeados que estejam transmitindo em uma garagem da empresa informada.
		GET /Posicao/Garagem?codigoEmpresa=0[&codigoLinha=0]
		Exemplo: https://api.olhovivo.sptrans.com.br/v2.1/Posicao/Garagem?codigoEmpresa=0[&codigoLinha=0]
	
	
8. Previsão de chegada
Retorna uma lista com a previsão de chegada dos veículos de cada uma das linhas que atendem ao ponto de parada informado.
	8.1 Get
		GET /Previsao?codigoParada={codigoParada}&codigoLinha={codigoLinha}
		Exemplo:
		
	8.2 Linha
		GET /Previsao/Linha?codigoLinha={codigoLinha}
		Exemplo:
		
	8.3 Parada
		GET /Previsao/Parada?codigoParada={codigoParada}
		Exemplo:

9. Velocidade nas vias
A categoria Velocidade nas Vias é a responsável por retornar um arquivo KMZ contendo um mapa de fluidez da cidade com a velocidade média e tempo de percurso de cada trecho envolvido.
	9.1 Get
	Retorna o mapa completo da cidade
		GET
		Exemplo:
	
	9.2 Corredor
	Retorna o mapa completo de todos os corredores da cidade
		GET
		Exemplo:
	
	9.3 OutrasVias
	Retorna o mapa completo com as vias importantes da cidade (exceto corredores)
		GET
		Exemplo:
		
		
		
		
CHAVES RELEVANTES
CL : Código identificador da linha. Este é um código identificador único de cada linha do sistema (por sentido de operação)		
	Linhas > Buscar
	Linhas > BuscarLinhaSentido
	Posição dos veículos > Posicao
	Previsão de Chegada > Get
	Previsão de Chegada > Parada

CP : Código identificador da parada
	Paradas > Buscar
	Paradas > BuscarParadasPorLinha
	Paradas > BuscarParadasPorCorredor

CC : Código identificador da corredor

C : Código de referência da empresa
Empresas > Empresa